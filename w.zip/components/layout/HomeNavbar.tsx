import { Dropdown } from "react-bootstrap";
import { FaBars, FaCaretDown, FaTimes } from "react-icons/fa";
import Link from 'next/link';
import routes from "config/routes";
import React from 'react';

interface IProps { }

interface IMobileProps {
    isActive: boolean;
    className?: string;
}

const Menu = (props: IMobileProps) => {
    return (
        <aside className={`mobile-menu border border-gray-200 shadow-lg bg-white ${props.isActive ? 'active' : null} ${props.className}`}>
            <div className="flex flex-col items-start">
                <div className={`mb-2 border-b border-gray-100 pb-2 w-full`}>
                    <Link href={routes.tickers}>
                        <a className={`text-sm mx-4 hover:text-blue-300 hover:font-extrabold t-black`}>Buy/Sell</a>
                    </Link>
                </div>
                <div className={`mb-2 border-b border-gray-100 pb-2 w-full`}>
                    <Link href={routes.tickers}>
                        <a className={`text-sm mx-4 hover:text-blue-300 hover:font-extrabold t-black`}>Tickers</a>
                    </Link>
                </div>
                <div className={`mb-2 border-b border-gray-100 pb-2 w-full`}>
                    <Link href={routes.aboutUs}>
                        <a className={`text-sm t-black mx-4`}>About Us</a>
                    </Link>
                </div>
                <div className={`mb-2 border-b border-gray-100 pb-2 w-full`}>
                    <Link href={routes.help}>
                        <a className={`text-sm t-black mx-4`}>Help &amp; FAQs</a>
                    </Link>
                </div>
                <div className={`mb-2 border-b border-gray-100 pb-2 w-full`}>
                    <Link href={routes.account}>
                        <a className={`text-sm t-black mx-4`}>My Dashboard</a>
                    </Link>
                </div>
                <div className={`flex flex-row mt-4 pl-4`}>
                    <button className="rounded-md bg-blue-500 text-xxs text-white px-4 py-2 hover:bg-blue-600">
                        Sign Up
                    </button>
                    <button className="rounded-md bg-gray-50 text-xxs t-black ml-3 px-4 py-2 border border-gray-200 hover:bg-blue-200">
                        Log In
                    </button>
                </div>
            </div>
        </aside>
    );
}

const HomeNavbar = (props: IProps) => {
    const [isSidebarOpen, setIsSidebarOpen] = React.useState(false);

    return (
        <nav className="w-full home-nav pb-3 pt-3 md:pt-3 fixed md:fixed top-0 z-10 flex flex-row items-center justify-between px-3">
            <div className={`w-32 md:w-40 ml-2 md:ml-10 flex items-center`}>
                <img style={{ border: `` }} src={`/assets/images/logo-transparent.png`} alt={`Bitcyclin`} />
                {/* <img style={{ border: `` }} src={`/assets/images/logo.png`} alt={`Bitcyclin`} /> */}
                {/* <span className={`uppercase text-2xl md:text-3xl ml-1 monospace font-bold text-blue-400`}>
                    Bitcyclin
                </span> */}
            </div>

            <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className={`xl:hidden transition duration-300`}>
                {
                    !isSidebarOpen ? <FaBars size={25} color={`black`} /> : <FaTimes size={25} color={`black`} />
                }
            </button>

            <div className="xl:flex hidden flex-row items-center pr-20">
                <Dropdown>
                    <Dropdown.Toggle onMouseEnter={e => e.currentTarget.click()} className={`flex hover:text-blue-300 hover:font-extrabold text-white`}>
                        <span className="text-white text-md mr-1 text-sm">
                            Buy/Sell
                        </span>
                        <FaCaretDown />
                    </Dropdown.Toggle>

                    <Dropdown.Menu className={`pt-6`}>
                        <div className={`flex flex-col py-2 px-2 bg-gray-900 text-white rounded-sm`}>
                            <Dropdown.Item className={`pb-2 pt-2 text-xs border-b border-gray-800 hover:border-gray-200`} >The quick brown fox</Dropdown.Item>
                            <Dropdown.Item className={`pb-2 pt-2 text-xs border-b border-gray-800 hover:border-gray-200`} >The quick brown fox</Dropdown.Item>
                            <Dropdown.Item className={`pb-2 pt-2 text-xs border-b border-gray-800 hover:border-gray-200`} >The quick brown fox</Dropdown.Item>
                        </div>
                    </Dropdown.Menu>
                </Dropdown>
                <Link href={routes.tickers}>
                    <a className={`text-sm mx-4 hover:text-blue-300 hover:font-extrabold text-white`}>Tickers</a>
                </Link>
                <Link href={routes.aboutUs}>
                    <a className={`text-sm mx-4 hover:text-blue-300 hover:font-extrabold text-white`}>About Us</a>
                </Link>
                <Link href={routes.help}>
                    <a className={`text-sm mx-4 hover:text-blue-300 hover:font-extrabold text-white`}>Help &amp; FAQs</a>
                </Link>
                <Dropdown>
                    <Dropdown.Toggle onMouseEnter={e => e.currentTarget.click()} className={`flex hover:text-blue-300 hover:font-extrabold text-white`}>
                        <span className="text-white text-md mr-1 text-sm hover:text-blue-300 hover:font-extrabold">
                            My Account
                        </span>
                        <FaCaretDown />
                    </Dropdown.Toggle>

                    <Dropdown.Menu className={`pt-6`}>
                        <div className={`flex flex-col py-2 px-2 bg-gray-900 text-white rounded-sm`}>
                            <Dropdown.Item className={`pb-2 pt-2 text-xs border-b border-gray-800 hover:border-gray-200`} >The quick brown fox</Dropdown.Item>
                            <Dropdown.Item className={`pb-2 pt-2 text-xs border-b border-gray-800 hover:border-gray-200`} >The quick brown fox</Dropdown.Item>
                            <Dropdown.Item className={`pb-2 pt-2 text-xs border-b border-gray-800 hover:border-gray-200`} >The quick brown fox</Dropdown.Item>
                        </div>
                    </Dropdown.Menu>
                </Dropdown>
            </div>

            <Menu isActive={isSidebarOpen} className={`top-16 w-full py-5 px-4`} />
        </nav>
    );
}

export default HomeNavbar;