import routes from 'config/routes';
import Link from 'next/link';


interface IProps { }

interface IL {
    title: string;
    href: string;
}
const L = (props: IL) => (
    <div className={`mb-1 border-b border-transparent hover:border-gray-200 pb-1 mt-2 transition duration-300 text-center lg:text-left`}>
        <Link href={props.href}>
            <a className={`text-gray-50 text-xs md:text-sm font-light`}>{props.title}</a>
        </Link>
    </div>
)

const HomeFooter = (props: IProps) => {
    return (
        <footer className={`flex flex-col w-full lg:flex-row bg-black justify-center py-4 lg:py-14 px-4 md:px-0`}>
            <aside className={`2xl:mr-52`}>
                <div className="flex items-center">
                    <img className={`h-14 md:h-28 mx-auto`} src={`/assets/images/logo-transparent.png`} />
                    {/* <img className={`h-20 md:h-32`} src={`/assets/images/logo.png`} /> */}
                    <div>
                        <h1 className={`md:text-4xl hidden mb-2 md:mb-4 text-xl text-gray-300 pl-4 md:pl-0`}>
                            Bitcyclin
                        </h1>
                        <p className="text-gray-200 lg:text-2xl hidden text-sm font-light pl-4 md:pl-0">
                            Lightning-fast cryptocurrency exchange platform
                        </p>
                    </div>
                </div>
            </aside>

            <main className={`lg:w-4/12 mt-4 md:mt-6 lg:mt-0 w-full lg:ml-20 flex flex-col lg:flex-row justify-around md:justify-around`}>
                <div>
                    <h3 className={`text-white text-sm md:text-md mb-3 text-center lg:text-left pt-4 md:pt-6 lg:pt-0`}>
                        Get Started
                    </h3>
                    <L title={`Sign Up`} href={routes.aboutUs} />
                    <L title={`Market Watch`} href={routes.tickers} />
                    <L title={`Join Our Watchlist`} href={routes.terms} />
                    <L title={`Tips`} href={routes.privacy} />
                </div>
                <div>
                    <h3 className={`text-white text-sm md:text-md mb-3 text-center lg:text-left pt-4 md:pt-6 lg:pt-0`}>
                        Useful Links
                    </h3>
                    <L title={`Help & FAQs`} href={routes.help} />
                </div>
                <div>
                    <h3 className={`text-white text-sm md:text-md mb-3 text-center lg:text-left pt-4 md:pt-6 lg:pt-0`}>
                        Company
                    </h3>
                    <L title={`About Us`} href={routes.aboutUs} />
                    <L title={`Contact Us`} href={routes.contactUs} />
                    <L title={`Terms`} href={routes.terms} />
                    <L title={`Privacy Policy`} href={routes.privacy} />
                </div>
            </main>
        </footer>
    );
}

export default HomeFooter;