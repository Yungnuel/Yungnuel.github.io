import Head from 'next/head';
import { ReactElement } from 'react';


interface IPage {
    title?: string;
    content?: ReactElement;
    children?: ReactElement;
}

const Page = ({
    title,
    content,
    children,
}: IPage) => {
    return (
        <>
            <Head>
                <title>{title ?? `Bitcyclin - Lightning-fast crypto exchange`}</title>
                <meta name="author" content="Icheka Ozuru" />
                <meta name="description" content="Bitcyclin is a lightening-fast crypto trading.exchange platform" />
            </Head>
            <>
                {content ?? children}
            </>
        </>
    );
}

export default Page;