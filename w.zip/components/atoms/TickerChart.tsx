import React from 'react';
import { Line } from 'react-chartjs-2';

export interface ITickerChartFormat {
    data: any;
    useLabels: boolean;
    condense?: boolean;
    color?: string;
}

export const formatData = (
    {
        data,
        useLabels,
        condense,
        color
    }: ITickerChartFormat
) => {
    let fillColor;
    switch (color) {
        case 'red':
            fillColor = 'rgb(247, 218, 213)';
        case 'green':
            fillColor = 'rgb(220, 250, 223)';
        default:
            fillColor = 'lightblue';
    }

    let final: any = {
        labels: [],
        datasets: [
            {
                // label: 'Price',
                label: '',
                data: [],
                backgroundColor: 'white',
                borderColor: color,
                fill: {
                    target: `origin`,
                    above: fillColor
                },
                tension: 0
            }
        ]
    }

    let dates: Array<any> = [];
    let prices: Array<any> = [];
    if (condense) data = data.slice(0, 6);
    data.forEach((d: any, i: number) => {

        const timestamp = d[0] * 1000;
        const date = new Date(timestamp);

        const day = date.getDate();
        const month = date.getMonth();
        const year = date.getFullYear();

        dates.push(`${day}-${month}-${year}`);
        prices.push(d[4]);
    });

    dates.reverse();
    prices.reverse();
    if (useLabels) final.labels = dates;
    else final.labels = dates.map(() => '');
    final.datasets[0].data = prices;

    return final;
}

interface ITickerChart {
    data: Array<any>;
    useLabels?: boolean;
    condense?: boolean;
    color?: string;
}

const TickerChart = ({
    data, useLabels, condense, color
}: ITickerChart) => {
    const chartOptions = {
        tooltips: {
            intersect: false,
            mode: 'index'
        },
        responsive: true,
        maintainAspectRatio: true,
    }

    return (
        <div>
            <Line data={formatData({
                data,
                useLabels: useLabels ?? false,
                condense: condense ?? false,
                color: color ?? 'lightgreen'

            })} options={chartOptions} />
        </div>
    );
}

export default TickerChart;