import { ReactElement } from "react";

interface IHomeShortBanner {
    coinName: string;
    value: string;
    percent: string;
    position: string;
    image: ReactElement;
}

const HomeShortBanner = (props: IHomeShortBanner) => {
    return (
        <div className={`relative bg-white rounded-md shadow-xl w-full px-2 py-5 xl:mr-2 mr-20`}>
            <div className={`flex flex-row justify-end relative`}>
                <span className={`absolute top-0 left-1 w-12`}>
                    {props.image}
                </span>
                <button className="bg-purple-200 px-3 xl:px-2 py-1 text-sm xl:text-xs font-semibold rounded-md flex-center text-blue-800 mx-1">
                    Buy
                </button>
                <button className="bg-green-100 px-3 xl:px-2 py-1 text-sm xl:text-xs font-semibold rounded-md flex-center text-blue-800 mx-1">
                    Trade
                </button>
            </div>

            <div className={`text-sm font-medium t-black mt-7 xl:mt-4 xl:mb-3 mb-4`}>
                {props.coinName}
            </div>

            <div className={`flex justify-between items-center`}>
                <div className={`t-black font-light text-sm`}>
                    ${props.value}
                </div>
                <div className={`text-sm ${props.position == 'up' ? 'text-green-400' : 'text-red-400'}`}>
                    {props.position == 'up' ? '+' : '-'}{props.percent}%
                </div>
            </div>
        </div>
    );
}


export default HomeShortBanner;