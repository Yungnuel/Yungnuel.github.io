import ShortNewsCard, { IShortNewsCard } from "components/molecules/ShortNewsCard";
import routes from "config/routes";
import Link from 'next/link';

interface IProps { }

const news: Array<IShortNewsCard> = [
    {
        title: `The best way to exhange digital assets online`,
        endTime: `12 Aug. 2021`,
        link: routes.home,
    },
    {
        title: `The best way to exhange digital assets online`,
        endTime: `12 Aug. 2021`,
        link: routes.home,
    },
    {
        title: `The best way to exhange digital assets online`,
        endTime: `12 Aug. 2021`,
        link: routes.home,
    },
];

const ShortNewsSection = (props: IProps) => {
    return (
        <div className={`px-2 xl:flex flex-col xl:px-44 w-full`}>
            <div className={`lg:flex flex-row lg:justify-left`}>
                {
                    news.map((e: IShortNewsCard, i, a) => (
                        <div className={`md:mx-4 py-2 mx-auto ${i >= 1 && 'hidden lg:block'} w-11/12 xl:w-full shadow-xl border border-gray-200 bg-gray-100 rounded-md`}>
                            <ShortNewsCard title={e.title} link={e.link} image={e.image} endTime={``} />
                        </div>
                    ))
                }
            </div>
            <div className={`flex-center mt-4 w-full`}>
                <Link href={routes.news}>
                    <a className={`text-sm text-purple-200 hover:text-purple-600 transition duration-300 underline`}>View more</a>
                </Link>
            </div>
        </div>
    );
}


export default ShortNewsSection;