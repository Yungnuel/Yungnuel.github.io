import React from 'react';
import { FaDotCircle } from 'react-icons/fa';

interface IProps { }

const LocationChooser = (props: IProps) => {

    return (
        <aside className={`relative px-4 pb-6 pt-10 w-4/12 bg-gray-200 rounded-xl text-black`}>
            <div className={`absolute right-0 top-0 w-36 -z-10 rounded-r-lg overflow-hidden`}>
                <img src={`/assets/images/hero-effect.svg`} />
            </div>

            <div className="relative">
                <div className={`mb-2`}>
                    Choose a location
                </div>
                <button className={`t-black hover:bg-gray-400 transition duration-300 flex justify-between bg-gray-300 px-3 py-3 rounded-md w-full text-left`}>
                    <span>
                        Nigeria
                    </span>
                    <span>
                        <FaDotCircle color={`green`} />
                    </span>
                </button>
            </div>
        </aside>
    );
}


export default LocationChooser;