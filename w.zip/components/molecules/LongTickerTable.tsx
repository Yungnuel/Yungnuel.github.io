import TickerChart from "components/atoms/TickerChart";
import React from "react";
import { FaBitcoin, FaCaretDown, FaCaretUp, FaEthereum } from "react-icons/fa";
import { getHistorical, WST_BTC } from "services/x";

interface ILongTickerTable { }

const LongTickerTable = (props: ILongTickerTable) => {
    const [tickers, setTickers] = React.useState<any>();
    const [count, setCount] = React.useState(0);
    // coins
    const [coins, setCoins] = React.useState<Array<string>>([
        'BTC', 'ETH', 'LTC', 'ADA', 'ACH', 'ALGO',
        'AMP', 'ATOM', 'BAT', 'BCH', 'BNT', 'CLV',
        'DASH', 'DOGE', 'CGLD', 'ICP', 'KEEP', 'LINK',
        'PAX', 'QNT'
    ]);
    const [btc, setBtc] = React.useState<any>({});
    const [eth, setEth] = React.useState<any>({});
    const [ltc, setLtc] = React.useState<any>({});
    const [ada, setAda] = React.useState<any>({});
    const [ach, setAch] = React.useState<any>({});
    const [algo, setAlgo] = React.useState<any>({});

    const [amp, setAmp] = React.useState<any>({});
    const [atom, setAtom] = React.useState<any>({});
    const [bat, setBat] = React.useState<any>({});
    const [bch, setBch] = React.useState<any>({});
    const [bnt, setBnt] = React.useState<any>({});
    const [cgld, setCgld] = React.useState<any>({});
    const [clv, setClv] = React.useState<any>({});
    const [dash, setDash] = React.useState<any>({});
    const [doge, setDoge] = React.useState<any>({});
    const [icp, setIcp] = React.useState<any>({});
    const [keep, setKeep] = React.useState<any>({});
    const [link, setLink] = React.useState<any>({});
    const [pax, setPax] = React.useState<any>({});
    const [qnt, setQnt] = React.useState<any>({});
    // historic
    // hours
    const [hours, setHours] = React.useState<any>({});
    // days
    const [days, setDays] = React.useState<any>({});

    // WS();
    React.useEffect(() => {
        WST_BTC(
            setBtc, setEth, setLtc, setAda, setAch, setAlgo,
            setAmp, setAtom, setBat, setBch, setBnt, setCgld,
            setClv, setDash, setDoge, setIcp, setKeep, setLink,
            setQnt

        );
        coins.forEach(async (c: string) => {
            let d, h;
            d = await getHistorical(c, '86400');
            h = await getHistorical(c, '3600');
            switch (c) {
                case 'BTC':
                    setDays({ ...days, btc: d });
                    setHours({ ...hours, btc: h });
                    break;
                case 'ETH':
                    setDays({ ...days, eth: d });
                    setHours({ ...hours, eth: h });
                    break;
                case 'LTC':
                    setDays({ ...days, ltc: d });
                    setHours({ ...hours, ltc: h });
                    break;
                case 'ADA':
                    setDays({ ...days, ada: d });
                    setHours({ ...hours, ada: h });
                    break;
                case 'ACH':
                    setDays({ ...days, ach: d });
                    setHours({ ...hours, ach: h });
                    break;
                case 'ALGO':
                    setDays({ ...days, algo: d });
                    setHours({ ...hours, algo: h });
                    break;

                case 'AMP':
                    setDays({ ...days, amp: d });
                    setHours({ ...hours, amp: h });
                    break;
                case 'ATOM':
                    setDays({ ...days, ATOM: d });
                    setHours({ ...hours, ATOM: h });
                    break;
                case 'BAT':
                    setDays({ ...days, BAT: d });
                    setHours({ ...hours, BAT: h });
                    break;
                case 'BCH':
                    setDays({ ...days, BCH: d });
                    setHours({ ...hours, BCH: h });
                    break;
                case 'BNT':
                    setDays({ ...days, BNT: d });
                    setHours({ ...hours, BNT: h });
                    break;
                case 'CLV':
                    setDays({ ...days, CLV: d });
                    setHours({ ...hours, CLV: h });
                    break;
                case 'DASH':
                    setDays({ ...days, DASH: d });
                    setHours({ ...hours, DASH: h });
                    break;
                case 'DOGE':
                    setDays({ ...days, DOGE: d });
                    setHours({ ...hours, DOGE: h });
                    break;
                case 'CGLD':
                    setDays({ ...days, CGLD: d });
                    setHours({ ...hours, CGLD: h });
                    break;
                case 'ICP':
                    setDays({ ...days, ICP: d });
                    setHours({ ...hours, ICP: h });
                    break;
                case 'KEEP':
                    setDays({ ...days, KEEP: d });
                    setHours({ ...hours, KEEP: h });
                    break;
                case 'LINK':
                    setDays({ ...days, LINK: d });
                    setHours({ ...hours, LINK: h });
                    break;
                case 'PAX':
                    setDays({ ...days, PAX: d });
                    setHours({ ...hours, PAX: h });
                    break;
                case 'QNT':
                    setDays({ ...days, QNT: d });
                    setHours({ ...hours, QNT: h });
                    break;
            }
        })
    }, []);

    const extractAtHoursAgo = (ago: number, coin: string) => {
        const data = hours[coin];
        try {
            return data[0][4];
        } catch (e) {
            console.log(e, data);
            return 0;
        }
    }

    const extractAtDaysAgo = (ago: number, coin: string) => {
        const data = days[coin];
        try {
            return data[ago][4];
        } catch (e) {
            console.log(e, data);
            return 0;
        }
    }

    const difference = (n: number, o: number): React.ReactElement => {
        const diff = n - o;
        const pc = ((diff / o) * 100).toFixed(3);
        if (pc == 'Infinity') {

            console.log(n, 0, o);
            return (
                <span className={`text-gray-500 flex-center`}>
                    ...
                </span>
            );
        }

        if (n > o) {
            return (
                <span className={`text-green-300 flex-center`}>
                    +{pc}% <FaCaretUp size={20} />
                </span>
            );
        } else if (n < o) {
            return (
                <span className={`text-red-400 flex-center`}>
                    {pc}% <FaCaretDown size={20} />
                </span>
            );
        } else if (pc == 'NaN') {
            return (
                <span className={`text-blue-400 flex-center`}>
                    0% <FaCaretUp size={20} />
                </span>
            );
        } else {
            return (
                <span className={`text-blue-400 flex-center`}>
                    0% <FaCaretUp size={20} />
                </span>
            );
        }
    }


    return (
        <div className={`bg-black shadow-2xl w-full overflow-x-scroll md:overflow-auto`}>
            <table className={`w-full`}>
                <thead className={`sticky`}>
                    <tr className={`text-white font-bold`}>
                        <th className={`pt-8 pl-4 pb-3 text-center text-sm flex flex-center`}>
                            #
                        </th>
                        <th className={`border-b border-gray-700 hover:border-purple-700 pt-8 pb-3 text-center text-sm`}>
                            Name
                        </th>
                        <th className={`border-b border-gray-700 hover:border-purple-700 pt-8 pb-3 text-center text-sm`}>
                            Price
                        </th>
                        <th className={`border-b border-gray-700 hover:border-purple-700 pt-8 pb-3 text-center text-sm`}>
                            Last 1h
                        </th>
                        <th className={`border-b border-gray-700 hover:border-purple-700 pt-8 pb-3 text-center text-sm`}>
                            Last 24h
                        </th>
                        <th className={`border-b border-gray-700 hover:border-purple-700 pt-8 pb-3 text-center text-sm`}>
                            Last 7d
                        </th>
                        <th className={`border-b border-gray-700 hover:border-purple-700 pt-8 pb-3 text-center text-sm`}>
                            Market Cap.
                        </th>
                        <th className={`border-b border-gray-700 hover:border-purple-700 pt-8 pb-3 text-center text-sm`}>
                            Circulating <br /> Supply
                        </th>
                        <th className={`border-b border-gray-700 hover:border-purple-700 pt-8 pb-3 text-center text-sm`}>
                            Chart
                        </th>
                    </tr>
                </thead>
                <tbody>
                    {/* BTC */}
                    <tr className={`border-b border-gray-800 hover:bg-gray-900 transition duration-500`}>
                        <td className={`py-5 text-center flex-center pl-4 pr-0`}>
                            <FaBitcoin size={22} color={`goldenrod`} />
                        </td>
                        <td className={`py-5 text-center text-sm`}>
                            <span className={`text-white`}>
                                BTC
                            </span>
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            ${btc.price}
                        </td>
                        <td className={`py-5 text-center text-sm text-green-500 font-light`}>
                            {difference(btc.price, extractAtHoursAgo(1, 'btc'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(btc.price, btc.high_24h)}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(btc.price, extractAtDaysAgo(7, 'btc'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            $835,655
                        </td>
                        <td className={`py-5 text-center text-white text-sm`}>
                            18,987,500
                        </td>
                        <td className={`text-sm relative px-0 text-center h-14 object-fit flex justify-center overflow-hidden`}>
                            <div className={`w-52 absolute overflow-hidden -top-4`}>
                                <TickerChart data={days.btc ?? []} condense color={(btc.price > extractAtDaysAgo(7, 'btc')) ? 'lightgreen' : (btc.price < extractAtDaysAgo(7, 'btc')) ? 'red' : 'lightblue'} />
                            </div>
                        </td>
                    </tr>
                    {/* ETH */}
                    <tr className={`border-b border-gray-800 hover:bg-gray-900 transition duration-500`}>
                        <td className={`py-5 text-center flex-center pl-4 pr-0`}>
                            <FaEthereum size={22} color={`blue`} />
                        </td>
                        <td className={`py-5 text-center text-sm`}>
                            <span className={`text-white`}>
                                ETH
                            </span>
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            ${eth.price}
                        </td>
                        <td className={`py-5 text-center text-sm text-green-500 font-light`}>
                            {difference(eth.price, extractAtHoursAgo(1, 'eth'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(eth.price, eth.high_24h)}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(eth.price, extractAtDaysAgo(7, 'eth'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            $835,655
                        </td>
                        <td className={`py-5 text-center text-white text-sm`}>
                            18,987,500
                        </td>
                        <td className={`text-sm relative px-0 text-center h-14 object-fit flex justify-center overflow-hidden`}>
                            <div className={`w-52 absolute overflow-hidden -top-4`}>
                                <TickerChart data={days.eth ?? []} condense color={(eth.price > extractAtDaysAgo(7, 'eth')) ? 'lightgreen' : (eth.price < extractAtDaysAgo(7, 'eth')) ? 'red' : 'lightblue'} />
                            </div>
                        </td>
                    </tr>
                    {/* BCH */}
                    <tr className={`border-b border-gray-800 hover:bg-gray-900 transition duration-500`}>
                        <td className={`py-5 text-center flex-center pl-4 pr-0`}>
                            <img className={`rounded-full`} src={`/assets/images/coins/bch.png`} width={21} />
                        </td>
                        <td className={`py-5 text-center text-sm`}>
                            <span className={`text-white`}>
                                BCH
                            </span>
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            ${bch.price}
                        </td>
                        <td className={`py-5 text-center text-sm text-green-500 font-light`}>
                            {difference(bch.price, extractAtHoursAgo(1, 'bch'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(bch.price, bch.high_24h)}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(bch.price, extractAtDaysAgo(7, 'bch'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            $835,655
                        </td>
                        <td className={`py-5 text-center text-white text-sm`}>
                            18,987,500
                        </td>
                        <td className={`text-sm relative px-0 text-center h-14 object-fit flex justify-center overflow-hidden`}>
                            <div className={`w-52 absolute overflow-hidden -top-4`}>
                                <TickerChart data={days.bch ?? []} condense color={(bch.price > extractAtDaysAgo(7, 'bch')) ? 'lightgreen' : (bch.price < extractAtDaysAgo(7, 'bch')) ? 'red' : 'lightblue'} />
                            </div>
                        </td>
                    </tr>
                    {/* LTC */}
                    <tr className={`border-b border-gray-800 hover:bg-gray-900 transition duration-500`}>
                        <td className={`py-5 text-center flex-center pl-4 pr-0`}>
                            <img className={`rounded-full`} src={`/assets/images/ltc.svg`} width={21} />
                        </td>
                        <td className={`py-5 text-center text-sm`}>
                            <span className={`text-white`}>
                                LTC
                            </span>
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            ${ltc.price}
                        </td>
                        <td className={`py-5 text-center text-sm text-green-500 font-light`}>
                            {difference(ltc.price, extractAtHoursAgo(1, 'ltc'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(ltc.price, ltc.high_24h)}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(ltc.price, extractAtDaysAgo(7, 'ltc'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            $835,655
                        </td>
                        <td className={`py-5 text-center text-white text-sm`}>
                            18,987,500
                        </td>
                        <td className={`text-sm relative px-0 text-center h-14 object-fit flex justify-center overflow-hidden`}>
                            <div className={`w-52 absolute overflow-hidden -top-4`}>
                                <TickerChart data={days.ltc ?? []} condense color={(ltc.price > extractAtDaysAgo(7, 'ltc')) ? 'lightgreen' : (ltc.price < extractAtDaysAgo(7, 'ltc')) ? 'red' : 'lightblue'} />
                            </div>
                        </td>
                    </tr>
                    {/* ADA */}
                    <tr className={`border-b border-gray-800 hover:bg-gray-900 transition duration-500`}>
                        <td className={`py-5 text-center flex-center pl-4 pr-0`}>
                            <img className={`rounded-full`} src={`/assets/images/coins/ada.png`} width={21} />
                        </td>
                        <td className={`py-5 text-center text-sm`}>
                            <span className={`text-white`}>
                                ADA
                            </span>
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            ${ada.price}
                        </td>
                        <td className={`py-5 text-center text-sm text-green-500 font-light`}>
                            {difference(ada.price, extractAtHoursAgo(1, 'ada'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(ada.price, ada.high_24h)}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(ada.price, extractAtDaysAgo(7, 'ada'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            $835,655
                        </td>
                        <td className={`py-5 text-center text-white text-sm`}>
                            18,987,500
                        </td>
                        <td className={`text-sm relative px-0 text-center h-14 object-fit flex justify-center overflow-hidden`}>
                            <div className={`w-52 absolute overflow-hidden -top-4`}>
                                <TickerChart data={days.ada ?? []} condense color={(ada.price > extractAtDaysAgo(7, 'ada')) ? 'lightgreen' : (ada.price < extractAtDaysAgo(7, 'ada')) ? 'red' : 'lightblue'} />
                            </div>
                        </td>
                    </tr>
                    {/* ACH */}
                    <tr className={`border-b border-gray-800 hover:bg-gray-900 transition duration-500`}>
                        <td className={`py-5 text-center flex-center pl-4 pr-0`}>
                            <img className={`rounded-full`} src={`/assets/images/coins/ach.png`} width={21} />
                        </td>
                        <td className={`py-5 text-center text-sm`}>
                            <span className={`text-white`}>
                                ACH
                            </span>
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            ${ach.price}
                        </td>
                        <td className={`py-5 text-center text-sm text-green-500 font-light`}>
                            {difference(ach.price, extractAtHoursAgo(1, 'ach'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(ach.price, ach.high_24h)}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(ach.price, extractAtDaysAgo(7, 'ach'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            $835,655
                        </td>
                        <td className={`py-5 text-center text-white text-sm`}>
                            18,987,500
                        </td>
                        <td className={`text-sm relative px-0 text-center h-14 object-fit flex justify-center overflow-hidden`}>
                            <div className={`w-52 absolute overflow-hidden -top-4`}>
                                <TickerChart data={days.ach ?? []} condense color={(ach.price > extractAtDaysAgo(7, 'ach')) ? 'lightgreen' : (ach.price < extractAtDaysAgo(7, 'ach')) ? 'red' : 'lightblue'} />
                            </div>
                        </td>
                    </tr>
                    {/* ALGO */}
                    <tr className={`border-b border-gray-800 hover:bg-gray-900 transition duration-500`}>
                        <td className={`py-5 text-center flex-center pl-4 pr-0`}>
                            <img className={`rounded-full`} src={`/assets/images/coins/algo.png`} width={21} />
                        </td>
                        <td className={`py-5 text-center text-sm`}>
                            <span className={`text-white`}>
                                ALGO
                            </span>
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            ${algo.price}
                        </td>
                        <td className={`py-5 text-center text-sm text-green-500 font-light`}>
                            {difference(algo.price, extractAtHoursAgo(1, 'algo'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(algo.price, algo.high_24h)}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(algo.price, extractAtDaysAgo(7, 'algo'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            $835,655
                        </td>
                        <td className={`py-5 text-center text-white text-sm`}>
                            18,987,500
                        </td>
                        <td className={`text-sm relative px-0 text-center h-14 object-fit flex justify-center overflow-hidden`}>
                            <div className={`w-52 absolute overflow-hidden -top-4`}>
                                <TickerChart data={days.algo ?? []} condense color={(algo.price > extractAtDaysAgo(7, 'algo')) ? 'lightgreen' : (algo.price < extractAtDaysAgo(7, 'algo')) ? 'red' : 'lightblue'} />
                            </div>
                        </td>
                    </tr>
                    {/* AMP */}
                    <tr className={`border-b border-gray-800 hover:bg-gray-900 transition duration-500`}>
                        <td className={`py-5 text-center flex-center pl-4 pr-0`}>
                            <img className={`rounded-full`} src={`/assets/images/coins/amp.png`} width={21} />
                        </td>
                        <td className={`py-5 text-center text-sm`}>
                            <span className={`text-white`}>
                                AMP
                            </span>
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            ${amp.price}
                        </td>
                        <td className={`py-5 text-center text-sm text-green-500 font-light`}>
                            {difference(amp.price, extractAtHoursAgo(1, 'amp'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(amp.price, amp.high_24h)}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(amp.price, extractAtDaysAgo(7, 'amp'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            $835,655
                        </td>
                        <td className={`py-5 text-center text-white text-sm`}>
                            18,987,500
                        </td>
                        <td className={`text-sm relative px-0 text-center h-14 object-fit flex justify-center overflow-hidden`}>
                            <div className={`w-52 absolute overflow-hidden -top-4`}>
                                <TickerChart data={days.amp ?? []} condense color={(amp.price > extractAtDaysAgo(7, 'amp')) ? 'lightgreen' : (amp.price < extractAtDaysAgo(7, 'amp')) ? 'red' : 'lightblue'} />
                            </div>
                        </td>
                    </tr>
                    {/* ATOM */}
                    <tr className={`border-b border-gray-800 hover:bg-gray-900 transition duration-500`}>
                        <td className={`py-5 text-center flex-center pl-4 pr-0`}>
                            <img className={`rounded-full`} src={`/assets/images/coins/atom.png`} width={21} />
                        </td>
                        <td className={`py-5 text-center text-sm`}>
                            <span className={`text-white`}>
                                ATOM
                            </span>
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            ${atom.price}
                        </td>
                        <td className={`py-5 text-center text-sm text-green-500 font-light`}>
                            {difference(atom.price, extractAtHoursAgo(1, 'atom'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(atom.price, atom.high_24h)}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(atom.price, extractAtDaysAgo(7, 'atom'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            $835,655
                        </td>
                        <td className={`py-5 text-center text-white text-sm`}>
                            18,987,500
                        </td>
                        <td className={`text-sm relative px-0 text-center h-14 object-fit flex justify-center overflow-hidden`}>
                            <div className={`w-52 absolute overflow-hidden -top-4`}>
                                <TickerChart data={days.atom ?? []} condense color={(atom.price > extractAtDaysAgo(7, 'atom')) ? 'lightgreen' : (atom.price < extractAtDaysAgo(7, 'atom')) ? 'red' : 'lightblue'} />
                            </div>
                        </td>
                    </tr>
                    {/* BAT */}
                    <tr className={`border-b border-gray-800 hover:bg-gray-900 transition duration-500`}>
                        <td className={`py-5 text-center flex-center pl-4 pr-0`}>
                            <img className={`rounded-full`} src={`/assets/images/coins/bat.png`} width={21} />
                        </td>
                        <td className={`py-5 text-center text-sm`}>
                            <span className={`text-white`}>
                                BAT
                            </span>
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            ${bat.price}
                        </td>
                        <td className={`py-5 text-center text-sm text-green-500 font-light`}>
                            {difference(bat.price, extractAtHoursAgo(1, 'bat'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(bat.price, bat.high_24h)}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(bat.price, extractAtDaysAgo(7, 'bat'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            $835,655
                        </td>
                        <td className={`py-5 text-center text-white text-sm`}>
                            18,987,500
                        </td>
                        <td className={`text-sm relative px-0 text-center h-14 object-fit flex justify-center overflow-hidden`}>
                            <div className={`w-52 absolute overflow-hidden -top-4`}>
                                <TickerChart data={days.bat ?? []} condense color={(bat.price > extractAtDaysAgo(7, 'bat')) ? 'lightgreen' : (bat.price < extractAtDaysAgo(7, 'bat')) ? 'red' : 'lightblue'} />
                            </div>
                        </td>
                    </tr>
                    {/* BCH */}
                    <tr className={`border-b border-gray-800 hover:bg-gray-900 transition duration-500`}>
                        <td className={`py-5 text-center flex-center pl-4 pr-0`}>
                            <img className={`rounded-full`} src={`/assets/images/coins/bch.png`} width={21} />
                        </td>
                        <td className={`py-5 text-center text-sm`}>
                            <span className={`text-white`}>
                                BCH
                            </span>
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            ${bch.price}
                        </td>
                        <td className={`py-5 text-center text-sm text-green-500 font-light`}>
                            {difference(bch.price, extractAtHoursAgo(1, 'bch'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(bch.price, bch.high_24h)}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(bch.price, extractAtDaysAgo(7, 'bch'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            $835,655
                        </td>
                        <td className={`py-5 text-center text-white text-sm`}>
                            18,987,500
                        </td>
                        <td className={`text-sm relative px-0 text-center h-14 object-fit flex justify-center overflow-hidden`}>
                            <div className={`w-52 absolute overflow-hidden -top-4`}>
                                <TickerChart data={days.bch ?? []} condense color={(bch.price > extractAtDaysAgo(7, 'bch')) ? 'lightgreen' : (bch.price < extractAtDaysAgo(7, 'bch')) ? 'red' : 'lightblue'} />
                            </div>
                        </td>
                    </tr>
                    {/* BNT */}
                    <tr className={`border-b border-gray-800 hover:bg-gray-900 transition duration-500`}>
                        <td className={`py-5 text-center flex-center pl-4 pr-0`}>
                            <img className={`rounded-full`} src={`/assets/images/coins/bnt.png`} width={21} />
                        </td>
                        <td className={`py-5 text-center text-sm`}>
                            <span className={`text-white`}>
                                BNT
                            </span>
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            ${bnt.price}
                        </td>
                        <td className={`py-5 text-center text-sm text-green-500 font-light`}>
                            {difference(bnt.price, extractAtHoursAgo(1, 'bnt'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(bnt.price, bnt.high_24h)}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(bnt.price, extractAtDaysAgo(7, 'bnt'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            $835,655
                        </td>
                        <td className={`py-5 text-center text-white text-sm`}>
                            18,987,500
                        </td>
                        <td className={`text-sm relative px-0 text-center h-14 object-fit flex justify-center overflow-hidden`}>
                            <div className={`w-52 absolute overflow-hidden -top-4`}>
                                <TickerChart data={days.bnt ?? []} condense color={(bnt.price > extractAtDaysAgo(7, 'bnt')) ? 'lightgreen' : (bnt.price < extractAtDaysAgo(7, 'bnt')) ? 'red' : 'lightblue'} />
                            </div>
                        </td>
                    </tr>
                    {/* CGLD */}
                    <tr className={`border-b border-gray-800 hover:bg-gray-900 transition duration-500`}>
                        <td className={`py-5 text-center flex-center pl-4 pr-0`}>
                            <img className={`rounded-full`} src={`/assets/images/coins/cgld.png`} width={21} />
                        </td>
                        <td className={`py-5 text-center text-sm`}>
                            <span className={`text-white`}>
                                CGLD
                            </span>
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            ${cgld.price}
                        </td>
                        <td className={`py-5 text-center text-sm text-green-500 font-light`}>
                            {difference(cgld.price, extractAtHoursAgo(1, 'cgld'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(cgld.price, cgld.high_24h)}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(cgld.price, extractAtDaysAgo(7, 'cgld'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            $835,655
                        </td>
                        <td className={`py-5 text-center text-white text-sm`}>
                            18,987,500
                        </td>
                        <td className={`text-sm relative px-0 text-center h-14 object-fit flex justify-center overflow-hidden`}>
                            <div className={`w-52 absolute overflow-hidden -top-4`}>
                                <TickerChart data={days.cgld ?? []} condense color={(cgld.price > extractAtDaysAgo(7, 'cgld')) ? 'lightgreen' : (cgld.price < extractAtDaysAgo(7, 'cgld')) ? 'red' : 'lightblue'} />
                            </div>
                        </td>
                    </tr>
                    {/* CLV */}
                    <tr className={`border-b border-gray-800 hover:bg-gray-900 transition duration-500`}>
                        <td className={`py-5 text-center flex-center pl-4 pr-0`}>
                            <img className={`rounded-full`} src={`/assets/images/coins/clv.png`} width={21} />
                        </td>
                        <td className={`py-5 text-center text-sm`}>
                            <span className={`text-white`}>
                                CLV
                            </span>
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            ${clv.price}
                        </td>
                        <td className={`py-5 text-center text-sm text-green-500 font-light`}>
                            {difference(clv.price, extractAtHoursAgo(1, 'clv'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(clv.price, clv.high_24h)}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(clv.price, extractAtDaysAgo(7, 'clv'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            $835,655
                        </td>
                        <td className={`py-5 text-center text-white text-sm`}>
                            18,987,500
                        </td>
                        <td className={`text-sm relative px-0 text-center h-14 object-fit flex justify-center overflow-hidden`}>
                            <div className={`w-52 absolute overflow-hidden -top-4`}>
                                <TickerChart data={days.clv ?? []} condense color={(clv.price > extractAtDaysAgo(7, 'clv')) ? 'lightgreen' : (clv.price < extractAtDaysAgo(7, 'clv')) ? 'red' : 'lightblue'} />
                            </div>
                        </td>
                    </tr>
                    {/* DASH */}
                    <tr className={`border-b border-gray-800 hover:bg-gray-900 transition duration-500`}>
                        <td className={`py-5 text-center flex-center pl-4 pr-0`}>
                            <img className={`rounded-full`} src={`/assets/images/coins/dash.png`} width={21} />
                        </td>
                        <td className={`py-5 text-center text-sm`}>
                            <span className={`text-white`}>
                                DASH
                            </span>
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            ${dash.price}
                        </td>
                        <td className={`py-5 text-center text-sm text-green-500 font-light`}>
                            {difference(dash.price, extractAtHoursAgo(1, 'dash'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(dash.price, dash.high_24h)}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(dash.price, extractAtDaysAgo(7, 'dash'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            $835,655
                        </td>
                        <td className={`py-5 text-center text-white text-sm`}>
                            18,987,500
                        </td>
                        <td className={`text-sm relative px-0 text-center h-14 object-fit flex justify-center overflow-hidden`}>
                            <div className={`w-52 absolute overflow-hidden -top-4`}>
                                <TickerChart data={days.dash ?? []} condense color={(dash.price > extractAtDaysAgo(7, 'dash')) ? 'lightgreen' : (dash.price < extractAtDaysAgo(7, 'dash')) ? 'red' : 'lightblue'} />
                            </div>
                        </td>
                    </tr>
                    {/* DOGE */}
                    <tr className={`border-b border-gray-800 hover:bg-gray-900 transition duration-500`}>
                        <td className={`py-5 text-center flex-center pl-4 pr-0`}>
                            <img className={`rounded-full`} src={`/assets/images/coins/doge.png`} width={21} />
                        </td>
                        <td className={`py-5 text-center text-sm`}>
                            <span className={`text-white`}>
                                DOGE
                            </span>
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            ${doge.price}
                        </td>
                        <td className={`py-5 text-center text-sm text-green-500 font-light`}>
                            {difference(doge.price, extractAtHoursAgo(1, 'doge'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(doge.price, doge.high_24h)}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(doge.price, extractAtDaysAgo(7, 'doge'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            $835,655
                        </td>
                        <td className={`py-5 text-center text-white text-sm`}>
                            18,987,500
                        </td>
                        <td className={`text-sm relative px-0 text-center h-14 object-fit flex justify-center overflow-hidden`}>
                            <div className={`w-52 absolute overflow-hidden -top-4`}>
                                <TickerChart data={days.doge ?? []} condense color={(doge.price > extractAtDaysAgo(7, 'doge')) ? 'lightgreen' : (doge.price < extractAtDaysAgo(7, 'doge')) ? 'red' : 'lightblue'} />
                            </div>
                        </td>
                    </tr>
                    {/* ICP */}
                    <tr className={`border-b border-gray-800 hover:bg-gray-900 transition duration-500`}>
                        <td className={`py-5 text-center flex-center pl-4 pr-0`}>
                            <img className={`rounded-full`} src={`/assets/images/coins/icp.png`} width={21} />
                        </td>
                        <td className={`py-5 text-center text-sm`}>
                            <span className={`text-white`}>
                                ICP
                            </span>
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            ${icp.price}
                        </td>
                        <td className={`py-5 text-center text-sm text-green-500 font-light`}>
                            {difference(icp.price, extractAtHoursAgo(1, 'icp'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(icp.price, icp.high_24h)}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(icp.price, extractAtDaysAgo(7, 'icp'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            $835,655
                        </td>
                        <td className={`py-5 text-center text-white text-sm`}>
                            18,987,500
                        </td>
                        <td className={`text-sm relative px-0 text-center h-14 object-fit flex justify-center overflow-hidden`}>
                            <div className={`w-52 absolute overflow-hidden -top-4`}>
                                <TickerChart data={days.icp ?? []} condense color={(icp.price > extractAtDaysAgo(7, 'icp')) ? 'lightgreen' : (icp.price < extractAtDaysAgo(7, 'icp')) ? 'red' : 'lightblue'} />
                            </div>
                        </td>
                    </tr>
                    {/* KEEP */}
                    <tr className={`border-b border-gray-800 hover:bg-gray-900 transition duration-500`}>
                        <td className={`py-5 text-center flex-center pl-4 pr-0`}>
                            <img className={`rounded-full`} src={`/assets/images/coins/keep.png`} width={21} />
                        </td>
                        <td className={`py-5 text-center text-sm`}>
                            <span className={`text-white`}>
                                KEEP
                            </span>
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            ${keep.price}
                        </td>
                        <td className={`py-5 text-center text-sm text-green-500 font-light`}>
                            {difference(keep.price, extractAtHoursAgo(1, 'keep'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(keep.price, keep.high_24h)}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(keep.price, extractAtDaysAgo(7, 'keep'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            $835,655
                        </td>
                        <td className={`py-5 text-center text-white text-sm`}>
                            18,987,500
                        </td>
                        <td className={`text-sm relative px-0 text-center h-14 object-fit flex justify-center overflow-hidden`}>
                            <div className={`w-52 absolute overflow-hidden -top-4`}>
                                <TickerChart data={days.keep ?? []} condense color={(keep.price > extractAtDaysAgo(7, 'keep')) ? 'lightgreen' : (keep.price < extractAtDaysAgo(7, 'keep')) ? 'red' : 'lightblue'} />
                            </div>
                        </td>
                    </tr>
                    {/* LINK */}
                    <tr className={`border-b border-gray-800 hover:bg-gray-900 transition duration-500`}>
                        <td className={`py-5 text-center flex-center pl-4 pr-0`}>
                            <img className={`rounded-full`} src={`/assets/images/coins/link.png`} width={21} />
                        </td>
                        <td className={`py-5 text-center text-sm`}>
                            <span className={`text-white`}>
                                LINK
                            </span>
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            ${link.price}
                        </td>
                        <td className={`py-5 text-center text-sm text-green-500 font-light`}>
                            {difference(link.price, extractAtHoursAgo(1, 'link'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(link.price, link.high_24h)}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(link.price, extractAtDaysAgo(7, 'link'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            $835,655
                        </td>
                        <td className={`py-5 text-center text-white text-sm`}>
                            18,987,500
                        </td>
                        <td className={`text-sm relative px-0 text-center h-14 object-fit flex justify-center overflow-hidden`}>
                            <div className={`w-52 absolute overflow-hidden -top-4`}>
                                <TickerChart data={days.link ?? []} condense color={(link.price > extractAtDaysAgo(7, 'link')) ? 'lightgreen' : (link.price < extractAtDaysAgo(7, 'link')) ? 'red' : 'lightblue'} />
                            </div>
                        </td>
                    </tr>
                    {/* QNT */}
                    <tr className={`border-b border-gray-800 hover:bg-gray-900 transition duration-500`}>
                        <td className={`py-5 text-center flex-center pl-4 pr-0`}>
                            <img className={`rounded-full`} src={`/assets/images/coins/qnt.png`} width={21} />
                        </td>
                        <td className={`py-5 text-center text-sm`}>
                            <span className={`text-white`}>
                                QNT
                            </span>
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            ${qnt.price}
                        </td>
                        <td className={`py-5 text-center text-sm text-green-500 font-light`}>
                            {difference(qnt.price, extractAtHoursAgo(1, 'qnt'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(qnt.price, qnt.high_24h)}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            {difference(qnt.price, extractAtDaysAgo(7, 'qnt'))}
                        </td>
                        <td className={`py-5 text-center text-sm text-white`}>
                            $835,655
                        </td>
                        <td className={`py-5 text-center text-white text-sm`}>
                            18,987,500
                        </td>
                        <td className={`text-sm relative px-0 text-center h-14 object-fit flex justify-center overflow-hidden`}>
                            <div className={`w-52 absolute overflow-hidden -top-4`}>
                                <TickerChart data={days.qnt ?? []} condense color={(qnt.price > extractAtDaysAgo(7, 'qnt')) ? 'lightgreen' : (qnt.price < extractAtDaysAgo(7, 'qnt')) ? 'red' : 'lightblue'} />
                            </div>
                        </td>
                    </tr>

                </tbody>
            </table>
        </div>
    );
}


export default LongTickerTable;