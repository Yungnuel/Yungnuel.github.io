import { ReactElement } from "react";

interface IWhyChooseBitcyclinItem {
    title: string;
    icon: ReactElement;
    caption: string;
}

const WhyChooseBitcyclinItem = ({ title, icon, caption }: IWhyChooseBitcyclinItem) => {
    return (
        <div className="relative flex justify-start items-center lg:items-start">
            <span className={`rounded-full shadow-xl border bg-white border-gray-100 flex-center xl:w-20 xl:h-20 w-16 h-16`}>
                {icon}
            </span>
            <div className={`lg:ml-4 ml-8 absolute w-9/12 h-full right-0 top-2`}>
                <h3 className={`text-xl text-white`}>{title}</h3>
                <div className="text-white mt-3 text-md font-medium">
                    {caption}
                </div>
            </div>
        </div>
    );
}


export default WhyChooseBitcyclinItem;