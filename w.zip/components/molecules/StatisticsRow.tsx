interface IStatistics {
    figure: string;
    title: string;
}

interface IProps { }

const StatisticsRow = (props: IProps) => {
    const statistics: Array<IStatistics> = [
        {
            figure: '15k',
            title: 'trades handled successfully'
        },
        {
            figure: '5k+',
            title: 'customers served'
        },
        {
            figure: '$1.2M',
            title: 'equivalent volume traded'
        },
    ];

    return (
        <section className={`w-full gr-bg py-8 md:py-12 flex flex-col md:flex-row lg:justify-center md:items-center md:overflow-x-scroll md:px-2 lg:px-0 lg:overflow-hidden`}>
            {
                statistics.map(({ figure, title }) => (
                    <div className={`2xl:w-2/12 lg:w-4/12 xl:w-3/12 mb-10 md:mb-0 shadow-lg rounded-2xl border-t border-purple-900 px-5 flex md:justify-center items-center justify-start h-40 mx-10 md:mx-4 lg:mx-4`}>
                        <div className={`text-3xl md:text-5xl text-white`}>
                            {figure}
                        </div>
                        <div className={`ml-4 uppercase text-md md:text-xl text-white`}>
                            {title}
                        </div>
                    </div>
                ))
            }
        </section>
    );
}

export default StatisticsRow;