import { FaBitcoin } from "react-icons/fa";

interface ITickerTable { }

const TickerTable = (props: ITickerTable) => {
    return (
        <table className={`w-full bg-white rounded-l-3xl`}>
            <thead>
                <tr>
                    <th className={`text-center border-b border-gray-700 px-6 lg:px-0`}>
                        &nbsp;
                    </th>
                    <th className={`text-black px-2 lg:px-0 text-sm lg:text-md font-semibold text-center hover:border-purple-800 border-b border-gray-700 py-4 transition duration-700 cursor-pointer`}>
                        Name
                    </th>
                    {/* <th className={`text-black px-2 lg:px-0 text-sm lg:text-md font-semibold text-center hover:border-purple-800 border-b border-gray-700 py-4 transition duration-700 cursor-pointer`}>
                        Shortname
                    </th> */}
                    <th className={`text-black px-2 lg:px-0 text-sm lg:text-md font-semibold text-center hover:border-purple-800 border-b border-gray-700 py-4 transition duration-700 cursor-pointer`}>
                        USD
                    </th>
                    <th className={`text-black px-2 lg:px-0 text-sm lg:text-md font-semibold text-center hover:border-purple-800 border-b border-gray-700 py-4 transition duration-700 cursor-pointer`}>
                        24 Hours
                    </th>
                    <th className={`text-black px-2 lg:px-0 text-sm lg:text-md font-semibold text-center hover:border-purple-800 border-b border-gray-700 py-4 transition duration-700 cursor-pointer`}>
                        &nbsp;
                    </th>
                    <th className={`text-black px-2 lg:px-0 text-sm lg:text-md font-semibold text-center border-b border-gray-700 py-4 transition duration-700 cursor-pointer`}>
                        &nbsp;
                    </th>
                </tr>
            </thead>

            <tbody>
                {
                    [0, 0, 0, 0, 0].map(e => (
                        <tr className={`hover:bg-gray-50`}>
                            <td className={`py-3 pb-4 t-black text-center flex-center text-md font-light`}>
                                <FaBitcoin color={`goldenrod`} size={24} />
                            </td>
                            <td className={`py-3 text-black text-center text-md font-light border-b border-gray-200`}>
                                Bitcoin
                            </td>
                            {/* <td className={`py-3 text-black text-center text-md font-light border-b border-gray-200`}>
                                BTC
                            </td> */}
                            <td className={`py-3 text-black text-center text-md font-light border-b border-gray-200`}>
                                $45090
                            </td>
                            <td className={`py-3 text-green-500 text-center text-md font-medium border-b border-gray-200`}>
                                +1.8%
                            </td>
                            <td className={`py-3 text-black text-center text-md font-light border-b border-gray-200`}>
                                &nbsp;
                            </td>
                            <td className={`py-3 text-black text-center text-md font-light border-b border-gray-200`}>
                                <div className="flex">
                                    <button className="rounded-l-md bg-green-500 text-black hover:bg-green-700 transition duration-700 text-xs px-4 py-2">
                                        Buy
                                    </button>
                                    <button className="rounded-r-md bg-red-400 text-black hover:bg-red-600 transition duration-700 text-xs px-4 py-2">
                                        Sell
                                    </button>
                                </div>
                            </td>
                        </tr>
                    ))
                }
            </tbody>
        </table>
    );
}


export default TickerTable;