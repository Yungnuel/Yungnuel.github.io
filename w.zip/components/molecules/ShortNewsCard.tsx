export interface IShortNewsCard {
    image?: string | null;
    title: string;
    endTime: string;
    link: string;
}

const ShortNewsCard = (props: IShortNewsCard) => {
    return (
        <div className={`w-full bg-gray-100`}>
            <div className={`h-40 bg-gray-300 rounded-md mx-4 my-2 rounded-t-20`}>
                {props.image && <img src={props.image} alt={props.title} />}
            </div>
            <div className={`bg-gray-300 py-5 px-4 rounded-md mx-4 my-2 t-black text-xs`}>
                &nbsp;
            </div>
            <div className={`bg-gray-300 py-4 px-4 rounded-md mx-4 my-2 t-black text-xs`}>
                &nbsp;
            </div>
        </div>
    );
}


export default ShortNewsCard;