import HomeNavbar from "components/layout/HomeNavbar";
import Page from "components/layout/Page";
import LongTickerTable from "components/molecules/LongTickerTable";
import React from "react";
import { WST_BTC } from "services/x";
// import { WS } from "services/x";


interface IProps { }

const TickersPage = (props: IProps) => {
    const coins: Array<string> = ['BTC', 'ETH', 'LTC'];
    const data = React.useRef<any>({});

    return (
        <Page title={`Tickers | Bitcyclin.com`}>
            <div className="relative w-full">
                <div>
                    <HomeNavbar />
                </div>

                <section className={`gr-bg relative mt-0 pt-12 lg:pt-44 pb-22 lg:pb-32`}>
                    <div>
                        <h1 className={`text-white text-4xl font-bold text-center`}>
                            Live Exchange Rates
                        </h1>
                    </div>
                    <p className={`text-center mt-0 lg:mt-10 font-light leading-8 md:px-10 xl:px-64 xl:mx-14 text-xl px-3 lg:text-2xl text-center text-white`}>
                        Realtime cryptocurrency exchange rates
                    </p>
                </section>
                <section className={`bg-gray-400 w-full flex justify-center`}>
                    <div className={`w-full`}>
                        <LongTickerTable />
                    </div>
                </section>

            </div>

        </Page>
    );
}


export default TickersPage;