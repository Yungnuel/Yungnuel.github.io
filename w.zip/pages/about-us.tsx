import HomeNavbar from "components/layout/HomeNavbar";
import Page from "components/layout/Page";
import React from "react";

interface IProps { }

interface ITeamMember {
    name: string;
    image: string;
    title: string;
}

const TeamMember = ({ name, image, title }: ITeamMember) => (
    <div className={`shadow-2xl rounded-md bg-white mb-8 mx-4 pb-3 lg:pb-0`}>
        <div className={`h-48 flex`}>
            <img className={`mx-auto`} style={{ objectFit: `contain` }} src={image} alt={name} />
        </div>
        <div className={`pt-1 text-sm`}>
            {name}
        </div>
        <div className={`text-xs text-gray-800`}>
            {title}
        </div>
    </div>
);


const AboutUsPage = (props: IProps) => {
    const team: Array<ITeamMember> = [
        {
            name: 'Nut Johansen',
            title: 'Founder & Director',
            image: '/assets/images/team-1.jpeg'
        },
        {
            name: 'Messina Jim',
            title: 'Director',
            image: '/assets/images/team-2.jpeg'
        },
        {
            name: 'Anthony Hopkins',
            title: 'Director',
            image: '/assets/images/team-3.jpeg'
        },
        {
            name: 'Lou Cary',
            title: 'Co-Founder, Board Member',
            image: '/assets/images/team-4.jpeg'
        },
        {
            name: 'Peter Gab',
            title: 'Co-Founder and Chief Executive Officer',
            image: '/assets/images/team-5.jpeg'
        },
        {
            name: 'Makil Kgil',
            title: 'Chief Financial Officer',
            image: '/assets/images/team-6.jpeg'
        },
        {
            name: 'Fender Moore',
            title: 'VP of Product',
            image: '/assets/images/team-8.jpeg'
        },
    ];

    return (
        <Page title={`About Us | Bitcyclin`}>
            <div className="relative w-full">
                <div>
                    <HomeNavbar />
                </div>

                <section className={`gr-bg mt-0 pt-20 lg:pt-32 pb-4 lg:pb-8`}>
                    <div>
                        <h1 className={`text-white text-4xl font-bold text-center`}>
                            About Us
                        </h1>
                    </div>
                    <p className={`text-center mt-0 lg:mt-10 font-light leading-8 md:px-10 xl:px-64 xl:mx-14 text-xl px-3 lg:text-2xl text-center text-white`}>
                        The Platform Technology" or "Bitcyclin" provides access to crypto the future finance under the registered trademark "Bitcyclin" (domain name: https://Bitcyclin.com). Buy, sell, trade crypto and manage your balance across Wallet.
                    </p>
                    <p className={`text-center mt-4 font-light lg:px-64 lg:mx-14 text-2xl text-center text-white`}>

                    </p>

                    {/* <div className={`rounded-full border-2 h-60`}>
                        &nbsp;
                    </div> */}
                </section>

                <section className={`text-black font-light text-xl leading-8 pb-4 pt-10 px-3 md:px-10 xl:px-40 text-center`}>
                    The safety of your money is our highest priority. That is why we do not store any of your funds or your private keys. Everything remains in your full control at all times, and we offer a 100% funds safety guarantee on all orders

                    We buy and sell more than 100 different currencies, and there are no hidden fees - the rates you see include absolutely everything! You can buy 24/7, and we have support on hand if you need it.

                    We also have provided the most popular and widely used crypto wallet that enables anyone anywhere to control their own money.
                </section>

                <section className={`text-black font-light text-xl leading-8 mt-1 md:mt-14 pb-20 pt-10 px-3 md:px-10 xl:px-40 text-center`}>
                    <div>
                        <h1 className={`font-bold`}>
                            Our Team
                        </h1>
                    </div>
                    <div className={`flex flex-col lg:flex-row flex-wrap mt-6 lg:mt-20`}>
                        {
                            team.map(t => (
                                <div className={`w-full lg:w-3/12`}>
                                    <TeamMember name={t.name} image={t.image} title={t.title} />
                                </div>
                            ))
                        }
                    </div>
                </section>
            </div>
        </Page>
    );
}


export default AboutUsPage;