import HomeNavbar from "components/layout/HomeNavbar";
import Page from "components/layout/Page"
import LocationChooser from "components/molecules/LocationChooser";
import React from "react";
import { FormControl, InputGroup } from "react-bootstrap";
import { FaBitcoin, FaEthereum } from "react-icons/fa";
import { HiArrowDown } from "react-icons/hi";
import Link from 'next/link';
import routes from "config/routes";
import TickerTable from "components/molecules/TickerTable";
import WhyChooseBitcyclinItem from "components/molecules/WhyChooseBitcyclinItem";
import StatisticsRow from "components/molecules/StatisticsRow";
import HomeFooter from "components/layout/HomeFooter";
import ShortNewsSection from "components/organisms/ShortNewsSection";
import HomeShortBanner from "components/atoms/HomeShortBanner";

interface IProps { }


const IndexPage = (props: IProps) => {
    const [askLocation, setAskLocation] = React.useState(false);

    return (
        <Page>
            {
                askLocation
                    ? <div className={`flex-center w-full h100 bg-gray-400`}>
                        <LocationChooser />
                    </div>
                    :
                    <div className={`h100 pt-20 md:pt-0 relative w-full overflow-hidden md:overflow-y-scroll`}>
                        {/* <div className={`absolute -top-32 md:-top-64 text-right -right-28 md:-right-20 -z-10 hero-effect`}>
                            <img style={{ width: `100%` }} src={`/assets/images/hero-effect.png`} alt={`Bitcyclin`} />
                        </div> */}

                        <div className="relative w-full">
                            <div>
                                <HomeNavbar />
                            </div>

                            <div className={`home-underblanket`}>

                            </div>

                            <div className={`sm:mt-28 lg:mt-20`}>
                                <h1 className={`text-5xl hidden lg:text-6xl monospace font-bold text-center text-white`}>
                                    Bitcyclin
                                </h1>
                                <p className={`text-white pt-10 px-4 2xl:text-gray-400 lg:px-40 2xl:px-0 text-3xl md:text-4xl font-normal md:font-light md:font-normal text-center`}>
                                    Buying, selling and saving cryptocurrencies has never been easier
                                </p>
                            </div>

                            <div className={`flex flex-col relative lg:flex-row px-8 lg:px-10 xl:px-32 2xl:px-40 items-center mt-10 md:mt-4 2xl:mt-20`}>
                                <div className={`w-full`}>
                                    <h1 className={`text-4xl hidden text-white font-medium`}>
                                        Lightning-fast cryptocurrency exchange platform
                                    </h1>
                                    <div className={` xl:absolute top-28 lg:w-7/12 xl:w-5/12`}>
                                        <p className={`text-gray-400 text-xl font-normal`}>
                                            Buy, save and trade cryptocurrencies instantly. Transact with any wallet address or withdraw to your bank account hassle-free.
                                        </p>
                                        <div className="mt-8 md:flex lg:block justify-center">
                                            <button style={{ background: 'rgb(12, 0, 242)' }} className={` rounded-md text-white uppercase px-4 py-3 hover:bg-blue-700`}>
                                                Create order
                                            </button>
                                        </div>
                                    </div>

                                    <section className={`mt-10 xl:mt-64 pb-2 xl:pt-16 lg:pb-6 w-full lg:w-7/12 xl:w-full flex overflow-x-scroll xl:overflow-hidden`}>
                                        {
                                            [
                                                {
                                                    coinName: 'Bitcoin BTC',
                                                    value: '46,140.50',
                                                    percent: '12.45',
                                                    position: 'up',
                                                    image: <FaBitcoin size={22} color={`goldenrod`} />
                                                },
                                                {
                                                    coinName: 'Ethereum ETH',
                                                    value: '4,140.50',
                                                    percent: '25.12',
                                                    position: 'down',
                                                    image: <FaEthereum size={22} color={`blue`} />
                                                },
                                                {
                                                    coinName: 'Litecoin LTC',
                                                    value: '1,140.50',
                                                    percent: '6.12',
                                                    position: 'up',
                                                    image: <img style={{ width: 20 }} src={`/assets/images/ltc.svg`} />
                                                },
                                                {
                                                    coinName: 'Stellar XLM',
                                                    value: '4,140.50',
                                                    percent: '25.12',
                                                    position: 'down',
                                                    image: <img style={{ width: 20 }} src={`/assets/images/stellar.svg`} />
                                                },
                                            ].map(e => (
                                                <div className={`xl:w-3/12 w-full mr-3 xl:mr-4 xl:mt-16`}>
                                                    <HomeShortBanner image={e.image} coinName={e.coinName} value={e.value} percent={e.percent} position={e.position} />
                                                </div>
                                            ))
                                        }
                                    </section>
                                </div>

                                <div className={`w-full md:w-9/12 lg:absolute lg:-right-0 xl:static lg:w-5/12 xl:w-7/12 px-8 mt-8 md:pt-0 rounded-3xl shadow-2xl bg-white pb-8`}>
                                    <h1 className={`text-md md:text-3xl mb-8 md:px-7 text-center font-semibold`}>
                                        It's a good day to buy crypto
                                    </h1>
                                    <div>
                                        <div>
                                            From USD $
                                        </div>
                                        <InputGroup className="mb-3 mt-2 flex flex-row rounded-md border border-gray-300">
                                            <FormControl
                                                placeholder=""
                                                aria-label="Amount"
                                                className={`w-full rounded-l-md no-outline px-4 border focus:border-yellow-500`}
                                            />
                                            <InputGroup.Text className={`py-3 bg-gray-300 text-green-400 font-bold text-lg px-4 md:px-10 rounded-r-md`}>
                                                $
                                            </InputGroup.Text>
                                        </InputGroup>
                                    </div>

                                    <div className={`flex-center my-5`}>
                                        <HiArrowDown size={18} color={`gray`} />
                                        <i className={`transform rotate-180`}>
                                            <HiArrowDown size={18} color={`gray`} />
                                        </i>
                                    </div>

                                    <div>
                                        <div className={`flex`}>
                                            To Bitcoin <FaBitcoin color={`goldenrod`} className={`ml-2`} />
                                        </div>
                                        <InputGroup className="mb-3 mt-2 flex flex-row rounded-md border border-gray-300">
                                            <FormControl
                                                placeholder=""
                                                aria-label="Amount"
                                                className={`w-full rounded-l-md no-outline px-4 border focus:border-yellow-500`}
                                            />
                                            <InputGroup.Text className={`py-3 bg-gray-300 text-black text-lg px-3 md:px-8 rounded-r-md`}>
                                                <FaBitcoin color={`goldenrod`} className={`ml-2`} size={18} />
                                            </InputGroup.Text>
                                        </InputGroup>
                                    </div>

                                    <div className="flex-center mt-8 md:mt-6">
                                        <button className="bg-purple-600 hover:bg-blue-600 transition duration-300 rounded-md text-white uppercase px-4 py-3 text-sm">
                                            buy now
                                        </button>
                                    </div>
                                    <div className={`text-center mt-2`}>
                                        <Link href={routes.account}>
                                            <a className={`text-sm text-green-400 hover:underline`}>Or sell</a>
                                        </Link>
                                    </div>
                                </div>
                            </div>

                            <section className={`xl:mt-14 mt-20 bg-gray-100 pb-10 shadow-sm relative xl:px-20`}>
                                <div className="flex-center text-black text-xl md:text-2xl font-medium mb-0">
                                    <h1 className={`text-center md:text-center w-full xl:pl-64 mx-4 md:mx-0`}>The Future of Money</h1>
                                </div>
                                <div className={`flex justify-end relative`}>
                                    <div className={`absolute -top-40 left-0 border-2 border-gray-200 hidden xl:block shadow-2xl rounded-full overflow-hidden`} style={{ background: `url('/assets/images/future.jpeg')`, width: 460, height: 460 }}>
                                        {/* <div className={`absolute xl:-top-64 xl:left-10 w-40`}> */}
                                        {/* <svg width="400" height="956" viewBox="0 0 680 956" fill="none" xmlns="http://www.w3.org/2000/svg" className="HeroVariant__DefaultHeroImage-sc-1o7093z-6 fNmrnO"><circle cx="340" cy="428" r="340" fill="#F1F5FE"></circle><g filter="url(#prefix__filter0_dd)"><path d="M481 10H198c-32.032 0-58 25.968-58 58v720c0 32.032 25.968 58 58 58h283c32.032 0 58-25.968 58-58V68c0-32.032-25.968-58-58-58z" fill="url(#prefix__paint0_linear)"></path><path d="M472.489 22H206.511C176.406 22 152 47.222 152 78.335v699.33C152 808.778 176.406 834 206.511 834h265.978C502.594 834 527 808.778 527 777.665V78.335C527 47.222 502.594 22 472.489 22z" fill="url(#prefix__img1)"></path><g filter="url(#prefix__filter1_f)"><path d="M213.5 15.5c-38.883 0-67.5 23.943-67.5 61.343V783.5c0 20.5 11.5 57 65.5 57" stroke="url(#prefix__paint1_radial)"></path></g><g filter="url(#prefix__filter2_f)"><path d="M465.5 15c38.883 0 67.5 23.943 67.5 61.343V783c0 20.5-11.5 57-65.5 57" stroke="url(#prefix__paint2_radial)"></path></g></g><defs><filter id="prefix__filter0_dd" x="48" y="0" width="519" height="956" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB"><feFlood flood-opacity="0" result="BackgroundImageFix"></feFlood><feColorMatrix in="SourceAlpha" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"></feColorMatrix><feOffset dx="-32" dy="50"></feOffset><feGaussianBlur stdDeviation="30"></feGaussianBlur><feColorMatrix values="0 0 0 0 0.321569 0 0 0 0 0.321569 0 0 0 0 0.321569 0 0 0 0.25 0"></feColorMatrix><feBlend in2="BackgroundImageFix" result="effect1_dropShadow"></feBlend><feColorMatrix in="SourceAlpha" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"></feColorMatrix><feOffset dy="15"></feOffset><feGaussianBlur stdDeviation="7.5"></feGaussianBlur><feColorMatrix values="0 0 0 0 0.320833 0 0 0 0 0.320833 0 0 0 0 0.320833 0 0 0 0.1 0"></feColorMatrix><feBlend in2="effect1_dropShadow" result="effect2_dropShadow"></feBlend><feBlend in="SourceGraphic" in2="effect2_dropShadow" result="shape"></feBlend></filter><filter id="prefix__filter1_f" x="143.5" y="13" width="72" height="830" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB"><feFlood flood-opacity="0" result="BackgroundImageFix"></feFlood><feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape"></feBlend><feGaussianBlur stdDeviation="1" result="effect1_foregroundBlur"></feGaussianBlur></filter><filter id="prefix__filter2_f" x="463.5" y="12.5" width="72" height="830" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB"><feFlood flood-opacity="0" result="BackgroundImageFix"></feFlood><feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape"></feBlend><feGaussianBlur stdDeviation="1" result="effect1_foregroundBlur"></feGaussianBlur></filter><radialGradient id="prefix__paint1_radial" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="matrix(286.75008 212.24974 -632.54832 854.57482 179.75 390.25)"><stop stop-opacity="0.2"></stop><stop offset="1" stop-opacity="0"></stop></radialGradient><radialGradient id="prefix__paint2_radial" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="matrix(0 756.5 -2254.52 0 499 131)"><stop stop-opacity="0"></stop><stop offset="0.453" stop-opacity="0.2"></stop><stop offset="1" stop-opacity="0"></stop></radialGradient><linearGradient id="prefix__paint0_linear" x1="539" y1="654" x2="-169.5" y2="799.5" gradientUnits="userSpaceOnUse"><stop stop-color="#F2F2F3"></stop><stop offset="0.64" stop-color="#CACED2"></stop></linearGradient><pattern id="prefix__img1" patternUnits="objectBoundingBox" width="1" height="1" viewBox="0 0 375 812"><image href="https://assets.coinbase.com/assets/portfolio.352f1ebd5622fb93068757ca3a33b88b.svg" width="375" height="812"></image></pattern></defs></svg> */}
                                        {/* <img src={`/assets/images/future.jpeg`} /> */}
                                    </div>
                                    <div className={`flex justify-end w-full xl:w-7/12`}>
                                        <div className={`w-full`}>
                                            <p className={`text-black mt-0 text-lg md:text-2xl font-medium lg:font-medium px-8 text-center md:text-left`}>
                                                Money is any "asset" (asset:  an artifact that has value) that can be exchanged for another asset and is acceptable to a group or community of people as a valid, legal,
                                                tenderable commodity.
                                                {/* Like every asset, its value can appreciate or depreciate and its value is always set by the community that uses it. */}
                                            </p>
                                            <p className={`text-black mt-0 text-lg md:text-2xl font-medium lg:font-medium px-8 mt-5 text-center md:text-left`}>
                                                Cryptocurrencies are just money that can be created, exchanged and saved digitally. They have value and can be exchanged for other assets, such as goods and services, online.
                                                {/* This approach provides several advantages over traditional forms of money. Cryptocurrencies are more secure, decentralized and cannot be controlled by any government or organization. */}
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </section>

                            <section className={`md:mt-10 mt-6 mb-64 relative pt-4 bg-gray-50 xl:mt-28 lg:bg-white`}>
                                <div className="flex-center">
                                    <h1 className={`text-black text-2xl md:text-4xl font-bold w-8/12 text-center pb-3`}>
                                        These currencies are making the biggest moves today
                                    </h1>
                                </div>
                                <div style={{ width: '100%', }} className={`absolute -left-1 bg-black pt-0 lg:pt-3 bg-white shadow-xl border border-gray-100 2xl:border-none pb-6 w-11/12 mx-auto overflow-x-scroll px-0 md:px-0 md:overflow-hidden`}>
                                    <TickerTable />
                                    <div className="mt-4 flex-center">
                                        <Link href={routes.tickers}>
                                            <a className={`text-white font-normal border-b border-b-transparent hover:border-blue-500 transition duration-300`}>View market tickers</a>
                                        </Link>
                                    </div>
                                </div>
                            </section>

                            <section className={`md:mt-64 xl:pt-52 mt-64 pt-48 gr-bg pb-10`}>
                                <div className="">
                                    <h1 className="text-center text-white font-bold text-2xl md:text-4xl">
                                        Why Choose Bitcyclin
                                    </h1>
                                    <p className="text-center text-white text-md md:text-xl font-medium">
                                        Here's why our clients are loyal to us
                                    </p>
                                </div>
                                <div className={`mt-7 md:mt-14 lg:px-28 2xl:px-32`}>
                                    <div className="flex flex-col lg:flex-row lg:justify-center lg:px-0 2xl:px-64 ">
                                        <div className={`flex flex-col w-10/12 md:w-8/12 mx-auto lg:mx-0 lg:w-8/12 `}>
                                            {
                                                [
                                                    {
                                                        title: 'Manage your portfolio',
                                                        caption: 'Buy and sell popular digital currencies. Keep track of them in one place.',
                                                        icon: <svg width="30" height="32" viewBox="0 0 30 32"><g fill="none" fill-rule="evenodd"><path fill="#D4EEFF" d="M10 32h10V10H10z"></path><path fill="#1752F0" d="M20 32h10V0H20z"></path><path fill="#55B4FC" d="M0 32h10V19H0z"></path></g></svg>
                                                    },
                                                    {
                                                        icon: <svg width="36" height="38" viewBox="0 0 36 38"><g fill="none" fill-rule="evenodd"><path d="M17.813 9.5a2.375 2.375 0 002.375-2.375v-4.75a2.375 2.375 0 00-4.75 0v4.75A2.375 2.375 0 0017.811 9.5M29.688 9.5a2.375 2.375 0 002.375-2.375v-4.75a2.375 2.375 0 00-4.75 0v4.75A2.375 2.375 0 0029.688 9.5" fill="#D4EEFF"></path><path fill="#D4EEFF" d="M0 38h35.625V4.75H0z"></path><path fill="#55B4FC" d="M0 11.875h35.625V4.75H0z"></path><path d="M5.938 9.5a2.375 2.375 0 002.375-2.375v-4.75a2.375 2.375 0 00-4.75 0v4.75A2.375 2.375 0 005.937 9.5" fill="#D4EEFF"></path><path d="M27.313 4.75v2.375a2.375 2.375 0 004.75 0V4.75h-4.75zM5.938 9.5a2.375 2.375 0 002.375-2.375V4.75h-4.75v2.375A2.375 2.375 0 005.937 9.5" fill="#1752F0"></path><path d="M17.813 9.5a2.375 2.375 0 002.375-2.375v-4.75a2.375 2.375 0 00-4.75 0v4.75A2.375 2.375 0 0017.811 9.5" fill="#D4EEFF"></path><path d="M17.813 9.5a2.375 2.375 0 002.375-2.375V4.75h-4.75v2.375A2.375 2.375 0 0017.811 9.5" fill="#1752F0"></path><path fill="#FFF" d="M4.75 34.438h26.125V11.875H4.75z"></path><path fill="#1752F0" d="M12.69 26.329l3.359 3.359L26.125 19.61l-3.358-3.359z"></path><path fill="#1752F0" d="M16.049 29.688l3.359-3.36-6.244-6.243-3.359 3.36z"></path></g></svg>,
                                                        title: 'Recurring buys',
                                                        caption: 'Invest in cryptocurrency slowly over time by scheduling buys daily, weekly, or monthly.'
                                                    },
                                                    {
                                                        icon: <svg width="30" height="33" viewBox="0 0 30 33" fill="none"><path d="M15 0C9.106 0 4.284 4.64 4.284 11.344V25.78h21.429V11.344C25.714 4.64 20.892 0 14.999 0z" fill="#D4EEFF"></path><path d="M30 12.375H0V33h30V12.375z" fill="#56B4FC"></path><path d="M25.714 12.375H4.285v16.5h21.429v-16.5z" fill="#1652F0"></path><path d="M15 18.563l2.84 6.187h-5.68L15 18.562z" fill="#fff"></path><path d="M15 20.625c1.184 0 2.143-.923 2.143-2.063 0-1.139-.96-2.062-2.143-2.062-1.183 0-2.143.923-2.143 2.063 0 1.139.96 2.062 2.143 2.062z" fill="#fff"></path></svg>,
                                                        title: 'Vault protection',
                                                        caption: 'For added security, store your funds in a vault with time delayed withdrawals.'
                                                    },
                                                    {
                                                        icon: <svg width="36" height="38" viewBox="0 0 36 38"><g fill="none" fill-rule="evenodd"><path d="M17.813 9.5a2.375 2.375 0 002.375-2.375v-4.75a2.375 2.375 0 00-4.75 0v4.75A2.375 2.375 0 0017.811 9.5M29.688 9.5a2.375 2.375 0 002.375-2.375v-4.75a2.375 2.375 0 00-4.75 0v4.75A2.375 2.375 0 0029.688 9.5" fill="#D4EEFF"></path><path fill="#D4EEFF" d="M0 38h35.625V4.75H0z"></path><path fill="#55B4FC" d="M0 11.875h35.625V4.75H0z"></path><path d="M5.938 9.5a2.375 2.375 0 002.375-2.375v-4.75a2.375 2.375 0 00-4.75 0v4.75A2.375 2.375 0 005.937 9.5" fill="#D4EEFF"></path><path d="M27.313 4.75v2.375a2.375 2.375 0 004.75 0V4.75h-4.75zM5.938 9.5a2.375 2.375 0 002.375-2.375V4.75h-4.75v2.375A2.375 2.375 0 005.937 9.5" fill="#1752F0"></path><path d="M17.813 9.5a2.375 2.375 0 002.375-2.375v-4.75a2.375 2.375 0 00-4.75 0v4.75A2.375 2.375 0 0017.811 9.5" fill="#D4EEFF"></path><path d="M17.813 9.5a2.375 2.375 0 002.375-2.375V4.75h-4.75v2.375A2.375 2.375 0 0017.811 9.5" fill="#1752F0"></path><path fill="#FFF" d="M4.75 34.438h26.125V11.875H4.75z"></path><path fill="#1752F0" d="M12.69 26.329l3.359 3.359L26.125 19.61l-3.358-3.359z"></path><path fill="#1752F0" d="M16.049 29.688l3.359-3.36-6.244-6.243-3.359 3.36z"></path></g></svg>,
                                                        title: 'Mobile apps',
                                                        caption: 'Invest in cryptocurrency slowly over time by scheduling buys daily, weekly, or monthly.'
                                                    },
                                                ].map(c => (
                                                    <div className={`w-full mb-12 lg:mb-14 xl:mb-12`}>
                                                        <WhyChooseBitcyclinItem title={c.title} icon={c.icon} caption={c.caption} />
                                                    </div>
                                                ))
                                            }
                                        </div>

                                        <div className={`w-10/12 lg:w-full ml-8 md:mx-auto lg:ml-8 lg:mx-auto`}>
                                            <img src={`https://assets.coinbase.com/assets/coinbase-app.3b0bfd4cb6b7a7614c1e18472187f6b9.webp`} />
                                        </div>
                                    </div>
                                </div>
                            </section>

                            <section className={`mt-20 md:mt-10 lg:mt-20`}>
                                <div className={`mb-16`}>
                                    <h1 className={`text-center text-md`}>
                                        5k+ people trust us to make them rich
                                    </h1>
                                </div>
                                <StatisticsRow />
                            </section>

                            <section className={`md:mt-20 mt-20`}>
                                <div>
                                    <h1 className={`text-center xl:text-4xl`}>
                                        Get started in 3 easy steps
                                    </h1>
                                    <p className="text-center text-gray-800 text-xl font-medium">
                                        You can go from noob to pro in your lunch break
                                    </p>
                                </div>
                                <div className={`flex-center pt-10 md:pl-10 lg:pl-0`}>
                                    {
                                        [
                                            {
                                                title: 'Create an account',
                                                caption: "You'll get several secure wallet addresses that will make buying or selling easy for you",
                                                icon: <span className={`flex-center text-xl border-2 border-gray-300 text-white font-bold bg-gray-200 w-20 h-20 xl:w-24 xl:h-24 rounded-full`}>1</span>,
                                            },
                                            {
                                                title: 'Create an account',
                                                caption: "You'll get several secure wallet addresses that will make buying or selling easy for you",
                                                icon: <span className={`flex-center text-xl border-2 border-gray-600 text-white font-bold bg-gray-500 w-20 h-20 xl:w-24 xl:h-24 rounded-full`}>2</span>,
                                            },
                                            {
                                                title: 'Create an account',
                                                caption: "You'll get several secure wallet addresses that will make buying or selling easy for you",
                                                icon: <span className={`flex-center text-xl border-2 border-gray-900 text-white font-bold bg-gray-900 w-20 h-20 xl:w-24 xl:h-24 rounded-full`}>3</span>,
                                            },
                                        ].map((c, i, a) => (
                                            <div className={`flex items-start w-3/12 md:w-4/12 lg:w-2/12 `}>
                                                <div>
                                                    <div className={`flex-center`}>
                                                        {c.icon}
                                                    </div>
                                                    <div className={`mt-6 text-lg text-center t-black`}>
                                                        {c.title}
                                                    </div>
                                                    <div className={`text-gray-600 pt-2 text-sm font-light text-center hidden md:block`}>
                                                        {c.caption}
                                                    </div>
                                                </div>
                                                {
                                                    i !== (a.length - 1) ? <span style={{ height: 2, }} className={`bg-gray-200 w-40 mt-12`}>{ }</span> : <span style={{ height: 2, }} className={`bg-transparent w-40 mt-12`}>{ }</span>
                                                }
                                            </div>
                                        ))
                                    }
                                </div>
                            </section>

                            <section className={`bg-gray-1003 gr-bg mt-20 pt-10 pb-6`}>
                                <h1 className={`text-3xl text-center lg:text-md monospace font-bold text-white`}>
                                    The latest updates in the industry.
                                </h1>
                                <div className={``}>
                                    <ShortNewsSection />
                                </div>
                            </section>

                            <section className={` w-full`}>
                                <HomeFooter />
                            </section>

                        </div>
                    </div >
            }
        </Page >
    );
}

export default IndexPage;