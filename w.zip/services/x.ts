import axios from 'axios';
import socketIOClient from 'socket.io-client';

const uri = process.env.NEXT_PUBLIC_BASEURL || 'http://localhost:4000';

let d: Array<any> = [];

export function WST_BTC(
    setBtc: (state: any) => void,
    setEth: (state: any) => void,
    setLtc: (state: any) => void,
    setAda: (state: any) => void,
    setAch: (state: any) => void,
    setAlgo: (state: any) => void,
    setAmp: (state: any) => void,
    setAtom: (state: any) => void,
    setBat: (state: any) => void,
    setBch: (state: any) => void,
    setBnt: (state: any) => void,
    setCgld: (state: any) => void,
    setClv: (state: any) => void,
    setDash: (state: any) => void,
    setDoge: (state: any) => void,
    setIcp: (state: any) => void,
    setKeep: (state: any) => void,
    setLink: (state: any) => void,
    setQnt: (state: any) => void,

): any {
    const socket = socketIOClient(uri as string, {
        reconnectionDelay: 1000,
        reconnection: true,
        // reconnectionAttemps: 10,
        transports: ['websocket'],
        agent: false,
        upgrade: false,
        rejectUnauthorized: false
    });

    socket.on('connection', socket => {
        console.log('CONNECTED!!');
    });

    // channels
    socket.on('BTC-USD', btc => {
        setBtc(JSON.parse(btc));
        // console.table(JSON.parse(btc));
    });
    socket.on('ETH-USD', eth => {
        setEth(JSON.parse(eth));
        // console.table(JSON.parse(eth));
    });
    socket.on('LTC-USD', data => {
        setLtc(JSON.parse(data));
        // console.table(JSON.parse(data));
    });
    socket.on('ADA-USD', data => {
        setAda(JSON.parse(data));
        // console.table(JSON.parse(data));
    });
    socket.on('ACH-USD', data => {
        setAch(JSON.parse(data));
        // console.table(JSON.parse(data));
    });
    socket.on('ALGO-USD', data => {
        setAlgo(JSON.parse(data));
        // console.table(JSON.parse(data));
    });

    socket.on('AMP-USD', data => {
        setAmp(JSON.parse(data));
        // console.table(JSON.parse(data));
    });
    socket.on('ATOM-USD', data => {
        setAtom(JSON.parse(data));
        // console.table(JSON.parse(data));
    });
    socket.on('BAT-USD', data => {
        setBat(JSON.parse(data));
        // console.table(JSON.parse(data));
    });
    socket.on('BCH-USD', data => {
        setBch(JSON.parse(data));
        // console.table(JSON.parse(data));
    });
    socket.on('BNT-USD', data => {
        setBnt(JSON.parse(data));
        // console.table(JSON.parse(data));
    });
    socket.on('CGLD-USD', data => {
        setCgld(JSON.parse(data));
        // console.table(JSON.parse(data));
    });
    socket.on('CLV-USD', data => {
        setClv(JSON.parse(data));
        // console.table(JSON.parse(data));
    });
    socket.on('DASH-USD', data => {
        setDash(JSON.parse(data));
        // console.table(JSON.parse(data));
    });
    socket.on('DOGE-USD', data => {
        setDoge(JSON.parse(data));
        // console.table(JSON.parse(data));
    });
    socket.on('ICP-USD', data => {
        setIcp(JSON.parse(data));
        // console.table(JSON.parse(data));
    });
    socket.on('KEEP-USD', data => {
        setKeep(JSON.parse(data));
        // console.table(JSON.parse(data));
    });
    socket.on('LINK-USD', data => {
        setLink(JSON.parse(data));
        // console.table(JSON.parse(data));
    });
    socket.on('QNT-USD', data => {
        setQnt(JSON.parse(data));
        // console.table(JSON.parse(data));
    });

    // ON ERROR
    socket.on('error', err => {
        console.log('An error occurred. Restarting socket client.');
        WST_BTC(
            setBtc, setEth, setLtc, setAda, setAch, setAlgo,
            setAmp, setAtom, setBat, setBch, setBnt, setCgld,
            setClv, setDash, setDoge, setIcp, setKeep, setLink,
            setQnt
        );
    });
}

export const getHistorical = async (coin: string, granularity: '60' | '300' | '3600' | '86400'): Promise<any> => {
    const histURI = `https://api.pro.coinbase.com/products/${coin + '-USD'}/candles?granularity=${granularity}`;

    const r = await fetch(histURI)
        .then(res => res.json())
        .then(data => data)
        .catch(err => {
            console.log(err);
            return null;
        });
    if (!r) return getHistorical(coin, granularity);
    else return r;
}