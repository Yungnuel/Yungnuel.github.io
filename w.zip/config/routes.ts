export default {
    home: '/',
    tickers: '/tickers',

    account: '/dashboard',

    signUp: '/signup',
    watchlist: '/watchlist',
    tips: '/tips',

    help: '/help',
    aboutUs: '/about-us',
    contactUs: '/contact-us',
    terms: '/terms',
    privacy: '/privacy',
    news: '/news'
}