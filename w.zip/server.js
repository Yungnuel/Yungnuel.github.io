const { createServer } = require('http');
const next = require('next');
const url = require('url');

const dev = process.env.NODE_ENV !== 'production';
const port = process.env.PORT ? process.env.PORT : 4000;

const app = next({ dev });
const requestHandler = app.getRequestHandler();

app.prepare().then(() => {
    createServer((req, res) => {
        // Be sure to pass `true` as the second argument to `url.parse`.
        // This tells it to parse the query portion of the URL.
        const uri = url.parse(req.url, true);

        requestHandler(req, res, uri);
    }).listen(3000, (err) => {
        if (err) throw err
        console.log(`> Ready on http://localhost:${port}`);
    })
})
